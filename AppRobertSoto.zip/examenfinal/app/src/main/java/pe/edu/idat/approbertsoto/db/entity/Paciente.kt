package pe.edu.idat.approbertsoto.db.entity
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tblrobert")
data class Paciente(
    @PrimaryKey val codpaciente: String,
    val password: String,
    val nombreapellido: String,
    val celular: String
)