package pe.edu.idat.approbertsoto.retrofit

import pe.edu.idat.approbertsoto.retrofit.api.TodoService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ClienteRetrofit {
    private const val BASE_URL = "https://jsonplaceholder.typicode.com/"

    val todoService: TodoService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TodoService::class.java)
    }
}