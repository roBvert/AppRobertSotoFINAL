package pe.edu.idat.approbertsoto.view

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import pe.edu.idat.approbertsoto.databinding.ActivityMainBinding
import pe.edu.idat.approbertsoto.db.PacienteRoomDatabase
import pe.edu.idat.approbertsoto.db.entity.Paciente

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val pacientes = listOf(
            Paciente("P001", "1234", "García López Juan", "987654321"),
            Paciente("P002", "abcd", "Ríos Torres María", "912345678"),
            Paciente("P003", "pass", "Soto Robert", "999888777")
        )

        binding.btnLogin.setOnClickListener {
            val cod = binding.etCodpaciente.text.toString().trim()
            val pass = binding.etPassword.text.toString().trim()

            val encontrado = pacientes.find {
                it.codpaciente == cod && it.password == pass
            }

            if (encontrado != null) {
                lifecycleScope.launch {
                    val db = PacienteRoomDatabase.getInstance(applicationContext)
                    db.pacienteDao().insertar(encontrado)

                    val intent = Intent(this@MainActivity, HomeActivity::class.java)
                    intent.putExtra("codpaciente", encontrado.codpaciente)
                    startActivity(intent)
                    finish()
                }
            } else {
                Toast.makeText(
                    this,
                    "Codpaciente o password incorrectos",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}