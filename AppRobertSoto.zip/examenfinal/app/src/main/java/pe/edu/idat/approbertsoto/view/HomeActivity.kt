package pe.edu.idat.approbertsoto.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import pe.edu.idat.approbertsoto.R
import pe.edu.idat.approbertsoto.databinding.ActivityHomeBinding
import pe.edu.idat.approbertsoto.view.fragment.PerfilFragment
import pe.edu.idat.approbertsoto.view.fragment.TodoFragment

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fragment por defecto al entrar
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, TodoFragment())
            .commit()

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_todos -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, TodoFragment())
                        .commit()
                    true
                }
                R.id.nav_perfil -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, PerfilFragment())
                        .commit()
                    true
                }
                else -> false
            }
        }
    }
}