package pe.edu.idat.approbertsoto.db
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import pe.edu.idat.approbertsoto.db.dao.PacienteDao
import pe.edu.idat.approbertsoto.db.entity.Paciente

@Database(entities = [Paciente::class], version = 1)
abstract class PacienteRoomDatabase : RoomDatabase() {
    abstract fun pacienteDao(): PacienteDao

    companion object {
        @Volatile private var INSTANCE: PacienteRoomDatabase? = null

        fun getInstance(context: Context): PacienteRoomDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    PacienteRoomDatabase::class.java,
                    "bdln72548625"
                ).build().also { INSTANCE = it }
            }
        }
    }
}