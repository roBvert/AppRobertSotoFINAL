package pe.edu.idat.approbertsoto.retrofit.response

data class TodoResponse(
    val userId: Int,
    val id: Int,
    val title: String,
    val completed: Boolean
)