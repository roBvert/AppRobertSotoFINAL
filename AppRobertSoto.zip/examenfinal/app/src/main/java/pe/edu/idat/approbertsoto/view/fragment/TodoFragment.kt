package pe.edu.idat.approbertsoto.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.coroutines.launch
import pe.edu.idat.approbertsoto.databinding.FragmentTodoBinding
import pe.edu.idat.approbertsoto.retrofit.ClienteRetrofit
import pe.edu.idat.approbertsoto.view.adapter.TodoAdapter

class TodoFragment : Fragment() {

    private var _binding: FragmentTodoBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: TodoAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTodoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Inicializar adapter vacío
        adapter = TodoAdapter(emptyList())
        binding.rvTodos.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTodos.adapter = adapter

        cargarTodos()
    }

    private fun cargarTodos() {
        lifecycleScope.launch {
            try {
                val todos = ClienteRetrofit.todoService.getTodos()
                // Filtrar solo completed == true
                val soloCompletados = todos.filter { it.completed }
                adapter.actualizarLista(soloCompletados)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}