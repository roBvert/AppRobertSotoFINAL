package pe.edu.idat.approbertsoto.view.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import pe.edu.idat.approbertsoto.databinding.FragmentPerfilBinding
import pe.edu.idat.approbertsoto.db.PacienteRoomDatabase

class PerfilFragment : Fragment() {

    private var _binding: FragmentPerfilBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPerfilBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Recuperar el codpaciente que pasamos desde MainActivity
        val codpaciente = activity?.intent?.getStringExtra("codpaciente") ?: ""

        lifecycleScope.launch {
            val db = PacienteRoomDatabase.getInstance(requireContext())
            val paciente = db.pacienteDao().buscarPorCod(codpaciente)

            paciente?.let {
                binding.tvNombre.text = "Nombre: ${it.nombreapellido}"
                binding.tvCelular.text = "Celular: ${it.celular}"
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}