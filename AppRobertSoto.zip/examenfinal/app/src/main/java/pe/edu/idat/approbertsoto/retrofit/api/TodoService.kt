package pe.edu.idat.approbertsoto.retrofit.api

import pe.edu.idat.approbertsoto.retrofit.response.TodoResponse
import retrofit2.http.GET

interface TodoService {
    @GET("todos")
    suspend fun getTodos(): List<TodoResponse>
}