package pe.edu.idat.approbertsoto.util

class Constantes {
}