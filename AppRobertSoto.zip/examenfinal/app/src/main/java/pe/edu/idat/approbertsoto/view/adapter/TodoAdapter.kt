package pe.edu.idat.approbertsoto.view.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import pe.edu.idat.approbertsoto.databinding.ItemTodoBinding
import pe.edu.idat.approbertsoto.retrofit.response.TodoResponse

class TodoAdapter(private var lista: List<TodoResponse>) :
    RecyclerView.Adapter<TodoAdapter.TodoViewHolder>() {

    inner class TodoViewHolder(val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        val binding = ItemTodoBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return TodoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        val todo = lista[position]
        holder.binding.tvUserId.text = "UserID: ${todo.userId}"
        holder.binding.tvId.text = "ID: ${todo.id}"
        holder.binding.tvTitle.text = todo.title
        holder.binding.tvCompleted.text = "Completado: ${todo.completed}"
    }

    override fun getItemCount() = lista.size

    fun actualizarLista(nuevaLista: List<TodoResponse>) {
        lista = nuevaLista
        notifyDataSetChanged()
    }
}