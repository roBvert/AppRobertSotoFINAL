package pe.edu.idat.approbertsoto.db.dao
import androidx.room.*
import pe.edu.idat.approbertsoto.db.entity.Paciente

@Dao
interface PacienteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertar(paciente: Paciente)

    @Query("SELECT * FROM tblrobert WHERE codpaciente = :cod LIMIT 1")
    suspend fun buscarPorCod(cod: String): Paciente?
}